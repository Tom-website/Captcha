# Captcha-Generator-plus-Validation
I created captcha Generator minor app with Validation of the Captcha generated. The whole Logic Behind it can be found in captcha.js file. Go there and check out the Logic.
